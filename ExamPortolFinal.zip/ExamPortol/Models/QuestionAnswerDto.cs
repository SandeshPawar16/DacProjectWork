﻿namespace ExamPortol.Models
{
    public class QuestionAnswerDto
    {

        public int QuesId { get; set; }
        public string GivenAnswer { get; set; }
    }
}
